export const ADD_ORGANIZATION = 'sos/Organization/ADD_ORGANIZATION'
export const MODAL_STATE = 'sos/Organization/MODAL_STATE'
export const ON_CHANGE_TEMP_ORG = 'sos/Organization/ON_CHANGE_TEMP_ORG'
export const SET_LOADED = 'sos/Organization/SET_LOADED'
