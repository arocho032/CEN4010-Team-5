export const SET_LOADED = 'sos/eventPage/SET_LOADED'
