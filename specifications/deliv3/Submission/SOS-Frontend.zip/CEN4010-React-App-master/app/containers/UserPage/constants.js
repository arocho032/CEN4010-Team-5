export const MODAL_LOAD = 'sos/UserPage/MODAL_LOAD'
export const MODAL_CLOSE = 'sos/UserPage/MODAL_CLOSE'
export const ON_CHANGE_TEMP_USER = 'sos/UserPage/ON_CHANGE_TEMP_USER'
export const SET_LOADED = 'sos/UserPage/SET_LOADED'

