export const ON_VIEW_CHANGE = 'sos/login/ON_VIEW_CHANGE'
