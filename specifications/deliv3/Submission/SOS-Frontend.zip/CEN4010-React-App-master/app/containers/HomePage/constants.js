export const SET_LOADED = 'sos/HomePage/SET_LOADED';
