import styled from 'styled-components';

const Header = styled.h4``;

export default Header;