package utils;

// TODO: Auto-generated Javadoc
/**
 * The Class Constants.
 */
public class Constants {

	/** The Constant SERVER_HOSTNAME. */
	public static final String SERVER_HOSTNAME = "localhost";
	
	/** The Constant SERVER_PORT. */
	public static final int SERVER_PORT = 9000;
	
	/** The Constant DB_HOSTNAME. */
	public static final String DB_HOSTNAME = "localhost";
	
	/** The Constant DB_PORT. */
	public static final int DB_PORT = 3308;
	
}
